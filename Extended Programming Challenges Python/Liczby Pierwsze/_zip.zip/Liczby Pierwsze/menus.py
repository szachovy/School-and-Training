GENERAL_MENU = 'Press q if you want to quit the program\n' \
               'Press 1. if you are ready to start selecting numbers\n' \
               'Press 2. if you want to see statistics\n'

SELECTING_MENU = 'Just start typing numbers\n'

STATISTICS_MENU = 'In this case you will see previous attempts\n'
